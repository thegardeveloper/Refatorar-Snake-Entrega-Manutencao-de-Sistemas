# Refatorar-Snake

Refatoração do jogo Snake em Python separando responsabilidades em módulos (`src/snake.py`, `src/food.py`, `src/game.py`) e adicionando suíte de testes automatizados com `pytest`.

## Como executar os testes

```bash
pip install -r requirements.txt
pytest --cov=src --cov-fail-under=80
```
