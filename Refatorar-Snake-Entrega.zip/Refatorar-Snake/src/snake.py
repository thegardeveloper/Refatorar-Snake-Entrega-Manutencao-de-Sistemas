import random
from typing import List, Optional, Tuple

Posicao = Tuple[int, int]

UP = 0
RIGHT = 1
DOWN = 2
LEFT = 4

DIRECOES_OPOSTAS = {
    UP: DOWN,
    DOWN: UP,
    LEFT: RIGHT,
    RIGHT: LEFT,
}


class Snake:
    def __init__(
        self,
        posicao_inicial: Optional[List[Posicao]] = None,
        direcao: int = LEFT,
        largura: int = 600,
        altura: int = 600,
        passo: int = 10,
    ) -> None:
        if posicao_inicial is not None:
            self.posicoes: List[Posicao] = list(posicao_inicial)
        else:
            self.posicoes = [(200, 200), (210, 200), (220, 200)]
        self.direcao: int = direcao
        self.largura: int = largura
        self.altura: int = altura
        self.passo: int = passo
        self.crescendo: bool = False

    def get_cabeca(self) -> Posicao:
        return self.posicoes[0]

    def get_corpo(self) -> List[Posicao]:
        return list(self.posicoes)

    def get_tamanho(self) -> int:
        return len(self.posicoes)

    def mudar_direcao(self, nova_direcao: int) -> None:
        if nova_direcao in DIRECOES_OPOSTAS and DIRECOES_OPOSTAS[nova_direcao] != self.direcao:
            self.direcao = nova_direcao

    def _calcular_proxima_posicao(self, direcao: Optional[int] = None) -> Posicao:
        dir_atual = self.direcao if direcao is None else direcao
        x, y = self.posicoes[0]
        if dir_atual == UP:
            return (x, y - self.passo)
        if dir_atual == DOWN:
            return (x, y + self.passo)
        if dir_atual == RIGHT:
            return (x + self.passo, y)
        if dir_atual == LEFT:
            return (x - self.passo, y)
        raise ValueError(f"Direção inválida: {dir_atual}")

    def mover(self, direcao: Optional[int] = None) -> Posicao:
        if direcao is not None:
            self.mudar_direcao(direcao)
        nova_pos = self._calcular_proxima_posicao()
        self.posicoes.insert(0, nova_pos)
        if self.crescendo:
            self.crescendo = False
        else:
            self.posicoes.pop()
        return nova_pos

    def crescer(self) -> None:
        self.posicoes.append((0, 0))

    def colidiu_parede(self) -> bool:
        x, y = self.posicoes[0]
        return x >= self.largura or y >= self.altura or x < 0 or y < 0

    def colidiu_proprio_corpo(self) -> bool:
        cabeca = self.posicoes[0]
        return cabeca in self.posicoes[1:]

    def colidiu_com_cobra(self, outra_cobra: "Snake") -> bool:
        cabeca = self.posicoes[0]
        return cabeca in outra_cobra.posicoes[1:-1]


class SnakeAI(Snake):
    def __init__(
        self,
        posicao_inicial: Optional[List[Posicao]] = None,
        direcao: int = LEFT,
        largura: int = 600,
        altura: int = 600,
        passo: int = 10,
    ) -> None:
        pos = posicao_inicial if posicao_inicial is not None else [(100, 100), (110, 100), (120, 100)]
        super().__init__(posicao_inicial=pos, direcao=direcao, largura=largura, altura=altura, passo=passo)
        self.deve_mover: bool = True

    def decidir_direcao(self, alvo: Posicao) -> int:
        cabeca_x, cabeca_y = self.posicoes[0]
        if alvo[0] > cabeca_x and self.direcao != LEFT:
            self.direcao = RIGHT
        if alvo[0] < cabeca_x and self.direcao != RIGHT:
            self.direcao = LEFT
        if alvo[1] > cabeca_y and self.direcao != UP:
            self.direcao = DOWN
        if alvo[1] < cabeca_y and self.direcao != DOWN:
            self.direcao = UP
        return self.direcao

    def _posicao_segura(self, pos: Posicao, jogador: Snake) -> bool:
        if pos in self.posicoes or pos in jogador.posicoes:
            return False
        if pos[0] < 0 or pos[1] < 0 or pos[0] >= self.largura or pos[1] >= self.altura:
            return False
        return True

    def atualizar(self, alvo: Posicao, jogador: Snake) -> None:
        if not self.deve_mover:
            return
        self.decidir_direcao(alvo)
        proxima = self._calcular_proxima_posicao()
        for i in range(len(self.posicoes) - 1, 0, -1):
            self.posicoes[i] = self.posicoes[i - 1]
        if not self._posicao_segura(proxima, jogador):
            rx = random.randint(0, (self.largura // self.passo) - 1) * self.passo
            ry = random.randint(0, (self.altura // self.passo) - 1) * self.passo
            self.posicoes[0] = (rx, ry)
        else:
            self.posicoes[0] = proxima
