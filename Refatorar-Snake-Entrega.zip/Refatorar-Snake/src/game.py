from typing import Optional
from food import Food
from snake import DOWN, LEFT, RIGHT, UP, Snake, SnakeAI


class Game:
    def __init__(self, largura: int = 600, altura: int = 600, passo: int = 10) -> None:
        self.largura: int = largura
        self.altura: int = altura
        self.passo: int = passo
        self.snake: Snake = Snake(largura=largura, altura=altura, passo=passo)
        self.snake_ai: SnakeAI = SnakeAI(largura=largura, altura=altura, passo=passo)
        self.food: Food = Food(largura=largura, altura=altura, passo=passo)
        self.score: int = 0
        self.score_ai: int = 0
        self.fase: int = 1
        self.vida: int = 3
        self.rodando: bool = True
        self.venceu: bool = False

    def atualizar_fase_e_vida(self) -> None:
        if self.score < 30:
            self.fase = 1
        if self.score >= 30:
            self.fase = 2
        if self.score == 40:
            self.vida += 1
        if self.score >= 50:
            self.fase = 3
        if self.score == 50:
            self.vida += 1
        if self.score >= 65:
            self.fase = 4
            self.venceu = True
            self.rodando = False

    def processar_comando(self, comando: str) -> None:
        cmd = comando.strip().upper()
        mapa = {
            "W": UP,
            "UP": UP,
            "S": DOWN,
            "DOWN": DOWN,
            "A": LEFT,
            "LEFT": LEFT,
            "D": RIGHT,
            "RIGHT": RIGHT,
        }
        if cmd == "QUIT":
            self.rodando = False
        elif cmd in mapa:
            self.snake.mudar_direcao(mapa[cmd])

    def _verificar_colisoes(self) -> None:
        if self.snake.colidiu_parede():
            self.vida = -1
        if self.vida < 0:
            self.rodando = False
            return

        if self.snake.colidiu_com_cobra(self.snake_ai):
            if self.fase == 3:
                self.vida += 1
                self.score_ai -= 1
            else:
                self.vida -= 1

        if self.snake.colidiu_proprio_corpo():
            self.vida -= 1

        if self.vida < 0:
            self.rodando = False

    def passo_jogo(self, comando: Optional[str] = None) -> None:
        if not self.rodando:
            return

        if comando is not None:
            self.processar_comando(comando)
            if not self.rodando:
                return

        self.atualizar_fase_e_vida()
        if self.fase == 4:
            return

        if self.food.foi_comida(self.snake.get_cabeca()):
            self.food.gerar_posicao()
            self.snake.crescer()
            self.score += 1

        self.snake.mover()
        self.snake_ai.atualizar(self.food.posicao, self.snake)

        if self.food.foi_comida(self.snake_ai.get_cabeca()):
            self.food.gerar_posicao()
            self.snake_ai.crescer()
            if self.fase == 3:
                self.score -= 1
            else:
                self.score_ai += 1

        self._verificar_colisoes()

    def rodar(self) -> None:
        while self.rodando:
            comando = input("Direção (UP/DOWN/LEFT/RIGHT/QUIT): ")
            self.passo_jogo(comando)

    def get_pontuacao(self) -> int:
        return self.score
