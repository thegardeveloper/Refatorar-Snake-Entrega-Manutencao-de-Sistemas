import random
from typing import Tuple

Posicao = Tuple[int, int]


class Food:
    def __init__(self, largura: int = 600, altura: int = 600, passo: int = 10) -> None:
        self.largura: int = largura
        self.altura: int = altura
        self.passo: int = passo
        self.posicao: Posicao = self.gerar_posicao()

    def gerar_posicao(self) -> Posicao:
        max_x = (self.largura // self.passo) - 1
        max_y = (self.altura // self.passo) - 1
        x = random.randint(0, max_x) * self.passo
        y = random.randint(0, max_y) * self.passo
        self.posicao = (x, y)
        return self.posicao

    def foi_comida(self, cabeca: Posicao) -> bool:
        return cabeca[0] == self.posicao[0] and cabeca[1] == self.posicao[1]
