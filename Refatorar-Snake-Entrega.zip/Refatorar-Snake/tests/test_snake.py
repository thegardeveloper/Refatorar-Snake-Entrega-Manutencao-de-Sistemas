import pytest
from snake import DOWN, LEFT, RIGHT, UP, Snake, SnakeAI


class TestSnake:
    def test_posicao_inicial_padrao(self) -> None:
        snake = Snake()
        assert snake.get_cabeca() == (200, 200)
        assert snake.get_tamanho() == 3
        assert snake.get_corpo() == [(200, 200), (210, 200), (220, 200)]

    @pytest.mark.parametrize(
        "direcao_inicial,direcao_nova,esperado",
        [
            (LEFT, UP, UP),
            (LEFT, DOWN, DOWN),
            (LEFT, RIGHT, LEFT),
            (RIGHT, LEFT, RIGHT),
            (UP, DOWN, UP),
            (DOWN, UP, DOWN),
        ],
    )
    def test_mudar_direcao_bloqueia_oposta(
        self, direcao_inicial: int, direcao_nova: int, esperado: int
    ) -> None:
        snake = Snake(posicao_inicial=[(100, 100)], direcao=direcao_inicial)
        snake.mudar_direcao(direcao_nova)
        assert snake.direcao == esperado

    @pytest.mark.parametrize(
        "direcao,cabeca_esperada",
        [
            (UP, (200, 190)),
            (DOWN, (200, 210)),
            (LEFT, (190, 200)),
            (RIGHT, (210, 200)),
        ],
    )
    def test_mover_todas_direcoes(self, direcao: int, cabeca_esperada: tuple) -> None:
        snake = Snake(posicao_inicial=[(200, 200)], direcao=direcao)
        nova = snake.mover()
        assert nova == cabeca_esperada
        assert snake.get_cabeca() == cabeca_esperada

    def test_direcao_invalida_lanca_erro(self) -> None:
        snake = Snake(posicao_inicial=[(100, 100)], direcao=99)
        with pytest.raises(ValueError):
            snake.mover()

    def test_crescer_aumenta_tamanho(self, snake_inicial: Snake) -> None:
        tamanho_antes = snake_inicial.get_tamanho()
        snake_inicial.crescer()
        assert snake_inicial.get_tamanho() == tamanho_antes + 1

    def test_mover_com_flag_crescendo(self) -> None:
        snake = Snake(posicao_inicial=[(100, 100)], direcao=RIGHT)
        snake.crescendo = True
        snake.mover()
        assert snake.get_tamanho() == 2
        assert snake.crescendo is False

    @pytest.mark.parametrize(
        "pos_cabeca,esperado",
        [
            ((-10, 100), True),
            ((600, 100), True),
            ((100, -10), True),
            ((100, 600), True),
            ((0, 0), False),
            ((590, 590), False),
        ],
    )
    def test_colisao_parede(self, pos_cabeca: tuple, esperado: bool) -> None:
        snake = Snake(posicao_inicial=[pos_cabeca])
        assert snake.colidiu_parede() is esperado

    def test_colisao_proprio_corpo(self) -> None:
        snake = Snake(posicao_inicial=[(100, 100), (110, 100), (100, 100)])
        assert snake.colidiu_proprio_corpo() is True

    def test_colisao_com_outra_cobra(self) -> None:
        jogador = Snake(posicao_inicial=[(110, 100), (120, 100)])
        inimiga = Snake(posicao_inicial=[(100, 100), (110, 100), (120, 100)])
        assert jogador.colidiu_com_cobra(inimiga) is True


class TestSnakeAI:
    def test_decidir_direcao_persegue_alvo(self, snake_ai_inicial: SnakeAI) -> None:
        snake_ai_inicial.direcao = UP
        assert snake_ai_inicial.decidir_direcao((200, 100)) == RIGHT

        snake_ai_inicial.direcao = UP
        assert snake_ai_inicial.decidir_direcao((50, 100)) == LEFT

        snake_ai_inicial.direcao = LEFT
        assert snake_ai_inicial.decidir_direcao((100, 200)) == DOWN

        snake_ai_inicial.direcao = LEFT
        assert snake_ai_inicial.decidir_direcao((100, 50)) == UP

    def test_atualizar_movimento_seguro(
        self, snake_ai_inicial: SnakeAI, snake_inicial: Snake
    ) -> None:
        snake_ai_inicial.atualizar((50, 100), snake_inicial)
        assert snake_ai_inicial.get_cabeca() == (90, 100)

    def test_atualizar_teleporta_em_colisao(
        self, snake_inicial: Snake, mocker
    ) -> None:
        ia = SnakeAI(posicao_inicial=[(0, 100), (10, 100)], direcao=LEFT)
        mocker.patch("snake.random.randint", side_effect=[15, 25])
        ia.atualizar((0, 100), snake_inicial)
        assert ia.get_cabeca() == (150, 250)

    def test_atualizar_ignora_quando_deve_mover_falso(
        self, snake_ai_inicial: SnakeAI, snake_inicial: Snake
    ) -> None:
        snake_ai_inicial.deve_mover = False
        cabeca_antes = snake_ai_inicial.get_cabeca()
        snake_ai_inicial.atualizar((50, 50), snake_inicial)
        assert snake_ai_inicial.get_cabeca() == cabeca_antes
