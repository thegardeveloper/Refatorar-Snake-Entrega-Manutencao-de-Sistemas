import pytest
from food import Food
from game import Game
from snake import LEFT, Snake, SnakeAI


@pytest.fixture
def snake_inicial() -> Snake:
    return Snake(posicao_inicial=[(200, 200), (210, 200), (220, 200)], direcao=LEFT)


@pytest.fixture
def snake_com_cauda(snake_inicial: Snake) -> Snake:
    snake_inicial.crescer()
    snake_inicial.crescer()
    return snake_inicial


@pytest.fixture
def snake_ai_inicial() -> SnakeAI:
    return SnakeAI(posicao_inicial=[(100, 100), (110, 100), (120, 100)], direcao=LEFT)


@pytest.fixture
def food_fixa() -> Food:
    food = Food()
    food.posicao = (300, 300)
    return food


@pytest.fixture
def game_padrao() -> Game:
    jogo = Game()
    jogo.food.posicao = (400, 400)
    return jogo
