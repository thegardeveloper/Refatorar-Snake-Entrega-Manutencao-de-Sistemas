import pytest
from food import Food
from game import Game
from snake import DOWN, LEFT, RIGHT, UP


class TestFood:
    def test_gerar_posicao_na_grade(self, mocker) -> None:
        mocker.patch("food.random.randint", side_effect=[5, 8])
        food = Food()
        assert food.posicao == (50, 80)

    def test_foi_comida(self, food_fixa: Food) -> None:
        assert food_fixa.foi_comida((300, 300)) is True
        assert food_fixa.foi_comida((310, 300)) is False


class TestGame:
    @pytest.mark.parametrize(
        "score,fase_esperada",
        [
            (0, 1),
            (29, 1),
            (30, 2),
            (50, 3),
            (65, 4),
        ],
    )
    def test_progressao_fases(self, game_padrao: Game, score: int, fase_esperada: int) -> None:
        game_padrao.score = score
        game_padrao.atualizar_fase_e_vida()
        assert game_padrao.fase == fase_esperada

    def test_bonus_vida_nos_marcos_40_e_50(self, game_padrao: Game) -> None:
        vida_base = game_padrao.vida
        game_padrao.score = 40
        game_padrao.atualizar_fase_e_vida()
        assert game_padrao.vida == vida_base + 1

        game_padrao.score = 50
        game_padrao.atualizar_fase_e_vida()
        assert game_padrao.vida == vida_base + 2

    def test_jogador_come_maca_e_pontua(self, game_padrao: Game, mocker) -> None:
        mocker.patch("food.random.randint", side_effect=[10, 10])
        game_padrao.food.posicao = game_padrao.snake.get_cabeca()
        tamanho_antes = game_padrao.snake.get_tamanho()

        game_padrao.passo_jogo("LEFT")

        assert game_padrao.get_pontuacao() == 1
        assert game_padrao.snake.get_tamanho() == tamanho_antes + 1

    def test_ia_come_maca_fase_normal_e_fase_3(self, game_padrao: Game, mocker) -> None:
        mocker.patch("food.random.randint", side_effect=[20, 20, 30, 30])
        game_padrao.food.posicao = (90, 100)
        game_padrao.passo_jogo()
        assert game_padrao.score_ai == 1

        game_padrao.score = 50
        game_padrao.food.posicao = (80, 100)
        game_padrao.passo_jogo()
        assert game_padrao.score == 49

    def test_colisao_parede_encerra_jogo(self, game_padrao: Game) -> None:
        game_padrao.snake.posicoes = [(0, 200), (10, 200)]
        game_padrao.passo_jogo("LEFT")
        assert game_padrao.vida == -1
        assert game_padrao.rodando is False

    def test_colisao_proprio_corpo_reduz_vida(self, game_padrao: Game) -> None:
        game_padrao.snake.posicoes = [(200, 200), (200, 190), (190, 190), (190, 200), (190, 210)]
        game_padrao.snake.direcao = UP
        vida_antes = game_padrao.vida
        game_padrao.passo_jogo("LEFT")
        assert game_padrao.vida == vida_antes - 1

    def test_colisao_com_ia_fase_1_vs_fase_3(self, game_padrao: Game) -> None:
        game_padrao.snake.posicoes = [(120, 100), (130, 100)]
        game_padrao.snake_ai.posicoes = [(100, 100), (110, 100), (120, 100)]
        game_padrao.snake_ai.deve_mover = False
        vida_antes = game_padrao.vida

        game_padrao.passo_jogo("LEFT")
        assert game_padrao.vida == vida_antes - 1

        game_padrao.score = 50
        game_padrao.score_ai = 5
        game_padrao.snake.posicoes = [(120, 100), (130, 100)]
        vida_fase3 = game_padrao.vida
        game_padrao.passo_jogo("LEFT")
        assert game_padrao.vida == vida_fase3 + 1
        assert game_padrao.score_ai == 4

    def test_game_loop_com_mock_input(self, game_padrao: Game, mocker) -> None:
        mocker.patch("builtins.input", side_effect=["UP", "RIGHT", "QUIT"])
        game_padrao.rodar()
        assert game_padrao.rodando is False
        assert game_padrao.get_pontuacao() == 0
